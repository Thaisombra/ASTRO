package model;

import java.util.ArrayList;
import java.util.List;

public class Atividade{
    private String nomeDaAtividade;
    private String descricao;
    private String dataInicio;
    private String dataFim;
    private List<String> participantes;

    //criando o construtor
    public Atividade(String nomeDaAtividade, String descricao, String dataInicio, String dataFim){
        this.nomeDaAtividade = nomeDaAtividade;
        this.descricao = descricao;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.participantes = new ArrayList<>(); //criando um objeto para adicionar os participantes
    }

    public void adicionarParticipante(String participante){
        //condição para verificar se o participante esta ou nao na equipe para adicioná-lo
        if(!participantes.contains(participante)){
            participantes.add(participante);
            System.out.println(participante + " foi adicionado à atividade.");
        }
        else{
            System.out.println(participante + " já está participando da atividade.");
        }
    }

    public void removerParticipante(String participante){
        // condição para verificar se o participante esta ou nao na equipe para removê-lo
        if(participantes.contains(participante)){
            participantes.remove(participante);
            System.out.println(participante + " foi removido da atividade.");
        }
        else{
            System.out.println(participante + " não está participando da atividade.");
        }
    }

    public String getNomeDaAtividade(){
        return nomeDaAtividade;
    }
    public void setNomeDaAtividade(String nomeDaAtividade){
        this.nomeDaAtividade = nomeDaAtividade;
    }

    public String getDescricao(){
        return descricao;
    }
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }

    public String getDataInicio(){
        return dataInicio;
    }
    public void setDataInicio(String dataInicio){
        this.dataInicio = dataInicio;
    }

    public String getDataFim(){
        return dataFim;
    }
    public void setDataFim(String dataFim){
        this.dataFim = dataFim;
    }

    public List<String> getParticipantes(){
        return participantes;
    }
    public void setParticipantes(List<String> participantes){
        this.participantes = participantes;
    }
}

