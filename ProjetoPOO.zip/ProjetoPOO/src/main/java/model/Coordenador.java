package model;

import java.util.ArrayList;
import java.util.List;

public class Coordenador extends Membro {
    private List<String> projetosCoordenados;
    private List<String> alunos;

    // Construtor
    public Coordenador(String nome, String cpf, String senha, int matricula, TipoDeMembro tipoDeMembro) {
        super(nome, cpf, senha, matricula, tipoDeMembro);
        this.projetosCoordenados = new ArrayList<>();
        this.alunos = new ArrayList<>();
    }

    // Getter para projetosCoordenados
    public List<String> getProjetosCoordenados() {
        return projetosCoordenados;
    }

    // Setter para projetosCoordenados
    public void setProjetosCoordenados(List<String> projetosCoordenados) {
        this.projetosCoordenados = projetosCoordenados;
    }

    // Getter para alunos
    public List<String> getAlunos() {
        return alunos;
    }

    // Método para cadastrar um projeto
    public void cadastrarProjeto(String nomeProjeto) {
        if (!projetosCoordenados.contains(nomeProjeto)) {
            projetosCoordenados.add(nomeProjeto);
            System.out.println("Projeto '" + nomeProjeto + "' cadastrado com sucesso.");
        } else {
            System.out.println("Projeto '" + nomeProjeto + "' já está cadastrado.");
        }
    }

    // Método para remover um projeto
    public void removerProjeto(String nomeProjeto) {
        if (projetosCoordenados.contains(nomeProjeto)) {
            projetosCoordenados.remove(nomeProjeto);
            System.out.println("Projeto '" + nomeProjeto + "' removido com sucesso.");
        } else {
            System.out.println("Projeto '" + nomeProjeto + "' não encontrado.");
        }
    }

    // Método para cadastrar um novo aluno
    public void cadastrarAluno(String nomeAluno) {
        if (!alunos.contains(nomeAluno)) {
            alunos.add(nomeAluno);
            System.out.println("Aluno '" + nomeAluno + "' cadastrado com sucesso.");
        } else {
            System.out.println("Aluno '" + nomeAluno + "' já está cadastrado.");
        }
    }

    // Método para remover um aluno
    public void removerAluno(String nomeAluno) {
        if (alunos.contains(nomeAluno)) {
            alunos.remove(nomeAluno);
            System.out.println("Aluno '" + nomeAluno + "' removido com sucesso.");
        } else {
            System.out.println("Aluno '" + nomeAluno + "' não encontrado.");
        }
    }
}
