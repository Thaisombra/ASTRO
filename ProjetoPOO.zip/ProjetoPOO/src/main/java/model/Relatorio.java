package model;

import java.util.List;

public class Relatorio {
    private String nomeAtividade;
    private int duracao;
    private List<String> participantes;

    public void gerarRelatorio() {
        // Implementation for gerarRelatorio
    }

    public void editarRelatorio() {
        // Implementation for editarRelatorio
    }

    public void visualizarRelatorio() {
        // Implementation for visualizarRelatorio
    }
}

