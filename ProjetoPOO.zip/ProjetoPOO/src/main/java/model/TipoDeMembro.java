package model;

public enum TipoDeMembro {
    COORDENADOR, BOLSISTA, VOLUNTARIO, ESTUDANTE, ALUNO, CONSULTOR
}

