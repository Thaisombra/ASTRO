package model;

import java.util.ArrayList;
import java.util.List;

public class Frequencia{
    private String nomeDaAtividade;
    private Membro matricula;
    private String nomeMembro;
    private boolean bolsista;
    private static List<Frequencia> registrosDeFrequencia = new ArrayList<>();

    //criando o construtor
    public Frequencia(String nomeDaAtividade, Membro matricula, String nomeMembro, boolean bolsista){
        this.nomeDaAtividade = nomeDaAtividade;
        this.matricula = matricula;
        this.nomeMembro = nomeMembro;
        this.bolsista = bolsista;
    }

    //cadastrando uma frequencia
    public void cadastrarFrequencia(){
        registrosDeFrequencia.add(this); //adicionando o proprio objeto a lista de registros
        System.out.println("Frequência cadastrada para: " + nomeMembro);
    }

    //abrindo uma frequencia
    public String visualizarFrequencia(){
        if (registrosDeFrequencia.isEmpty()){
            System.out.println("Nenhuma frequência cadastrada");
        }
        else{
            System.out.println("Frequências cadastradas:");
            for(int i = 0; i < registrosDeFrequencia.size(); i++){
                Frequencia frequencia = registrosDeFrequencia.get(i); //retorna o valor de i, a frequencia que queremos visualizar
                System.out.println("Atividade: " + frequencia.nomeDaAtividade +
                        ", Matrícula: " + frequencia.matricula +
                        ", Membro: " + frequencia.nomeMembro +
                        ", Bolsista: " + (frequencia.bolsista ? "Sim" : "Não")); //verifica se é um bolsista ou nao
            }
        }
        return "";
    }

    public String getNomeDaAtividade(){
        return nomeDaAtividade;
    }
    public void setNomeDaAtividade(String nomeDaAtividade){
        this.nomeDaAtividade = nomeDaAtividade;
    }

    public Membro getMatricula(){
        return matricula;
    }
    public void setMatricula(Membro matricula){
        this.matricula = matricula;
    }

    public String getNomeMembro(){
        return nomeMembro;
    }
    public void setNomeMembro(String nomeMembro){
        this.nomeMembro = nomeMembro;
    }

    public boolean isBolsista(){
        return bolsista;
    }

    public void setBolsista(boolean bolsista){
        this.bolsista = bolsista;
    }
}

