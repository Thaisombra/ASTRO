package model;

public class Membro {
    private String nome;
    private String cpf;
    private String senha;
    private int matricula;
    private int cargaHoraria;
    private int registroDeFrequencia;
    private TipoDeMembro tipoDeMembro;

    // Construtor
    public Membro(String nome, String cpf, String senha, int matricula, TipoDeMembro tipoDeMembro) {
        this.nome = nome;
        this.cpf = cpf;
        this.senha = senha;
        this.matricula = matricula;
        this.cargaHoraria = 0;
        this.registroDeFrequencia = 0;
        this.tipoDeMembro = tipoDeMembro;
    }

    // Validação de CPF
    public static boolean isValidCPF(String cpf) {
        cpf = cpf.replaceAll("\\D", "");
        return cpf.length() == 11;
    }

    // Validação de matrícula
    public static boolean isValidMatricula(int matricula) {
        return String.valueOf(matricula).length() == 6;
    }

    // Métodos para gerar relatórios e atualizar dados
    public void gerarRelatorioDeFrequencia() {
        System.out.println("Relatório de Frequência:");
        System.out.println("Nome: " + nome);
        System.out.println("Matrícula: " + matricula);
        System.out.println("Frequência: " + registroDeFrequencia + " dias");
    }

    public void adicionarRelatorio() {
        registroDeFrequencia++;
        System.out.println("Frequência atualizada para: " + registroDeFrequencia);
    }

    public void adicionarNovaAtividade(int horas) {
        cargaHoraria += horas;
        System.out.println("Carga horária atualizada para: " + cargaHoraria + " horas");
    }

    // Getters e Setters para todas as propriedades
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public int getRegistroDeFrequencia() {
        return registroDeFrequencia;
    }

    public void setRegistroDeFrequencia(int registroDeFrequencia) {
        this.registroDeFrequencia = registroDeFrequencia;
    }

    public TipoDeMembro getTipoDeMembro() {
        return tipoDeMembro;
    }

    public void setTipoDeMembro(TipoDeMembro tipoDeMembro) {
        this.tipoDeMembro = tipoDeMembro;
    }
}
