package org.example.projetopoo;

public class CoordenadorController {
}
